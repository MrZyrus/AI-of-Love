/*
Copyright (C) 2011, 2014 by the PSVN Research Group, University of Alberta
*/

typedef struct {
  int size;
  var_t *v;
} abst_array_t;

typedef struct {
  var_t *value_map[ NUMDOMAINS ];
  uint8_t project_away_var[ NUMVARS ];
  abst_array_t* mapped_in[ NUMDOMAINS ];
  int* fwd_rule_label_sets;
  int* bwd_rule_label_sets;
} abstraction_t;


static abstraction_t* allocate_abstraction()
{
    int i;
    int64_t s;
    abstraction_t* abst = (abstraction_t *)malloc( sizeof( *abst ) );
    if( abst == NULL )
        return NULL;
    
    for( s = 0, i = 0; i < NUMDOMAINS; ++i ) {
        s += domain_sizes[ i ];
    }
    abst->value_map[ 0 ]
        = (var_t * )malloc( sizeof( abst->value_map[ 0 ][ 0 ] ) * s );
    if( abst->value_map[ 0 ] == NULL ) {
        free( abst );
        return NULL;
    }
    abst->mapped_in[ 0 ] 
        = (abst_array_t*)malloc(sizeof(abst->mapped_in[0][0]) * s);
    if (abst->mapped_in[ 0 ] == NULL) {
        free(abst->value_map[0]);
        free(abst);
        return NULL;
    }
    for( s = domain_sizes[ 0 ], i = 1;
         i < NUMDOMAINS;
         s += domain_sizes[ i ], ++i ) 
    {
        abst->value_map[ i ] = &abst->value_map[ 0 ][ s ];
        abst->mapped_in[ i ] = &abst->mapped_in[ 0 ][ s ];
    }

    for (i = 0; i < NUMDOMAINS; ++i){
        abst->mapped_in[ i ][ 0 ].v 
            = (var_t*) malloc (sizeof(var_t) * domain_sizes[i]);
    }

    return abst;
}


static void destroy_abstraction( abstraction_t *abst )
{
    int i;
    for (i = 0; i < NUMDOMAINS; ++i)
        free ( abst->mapped_in[i][0].v );
    free( abst->mapped_in[ 0 ] );
    free( abst->value_map[ 0 ] );
    free( abst );
}



/* Fills in an abstraction's mapped_in array.
   Required for use in a dyanmic abstraction setting. Overwrites old
   mapped_in array. */
static void abstraction_compute_mapped_in(abstraction_t* abst)
{
    int i, j, k, n;
    int found[128];
    size_t size;
    for( i = 0; i < NUMDOMAINS; ++i ) {
        var_t* in = abst->mapped_in[i][0].v;
        for (j = 0; j < domain_sizes[i]; ++j) {
            abst->mapped_in[i][j].size = 0;
            abst->mapped_in[i][j].v = in;
            for (k = 0; k < domain_sizes[i]; ++k) {
                if (abst->value_map[i][k] == j) {
                    abst->mapped_in[i][j].size++;
                    *in++ = k;
                }
            }
        }
    }

    /* Compute the representative for variable equality comparisions.
       Suppose the LHS of a rule looks like "- A A A". The compiler
       will add the tests "var[2] == var[1]" and "var[3] ==
       var[1]". But what happens if var[1] is projected away? We need
       to compute the new representative of 'A' (which the compiler
       set to var[1] initially), by finding another A that isn't
       projected away, and use it for the comparison tests. */
    size = NUMVARS * num_fwd_rules * sizeof(int);
    abst->fwd_rule_label_sets = (int*) malloc (size);
    memcpy(abst->fwd_rule_label_sets, fwd_rule_label_sets, size);
    for (i = 0; i < num_fwd_rules; ++i) {
        for (j = 0; j < NUMVARS; ++j) {
            if (abst->project_away_var[j]) {
                n = 0;
                for (k = j + 1; k < NUMVARS; ++k)
                    if (!abst->project_away_var[k] 
                        && fwd_rule_label_sets[i*NUMVARS + k] == j)
                        found[n++] = k;
                /* Map others to new representative. */
                if (n > 0) {
                    abst->fwd_rule_label_sets[i*NUMVARS + j] = found[0];
                    for (k = 0; k < n; ++k)
                        abst->fwd_rule_label_sets[i*NUMVARS + found[k]] = found[0];
                }
            }
        }
    }
#ifdef HAVE_BWD_MOVES
    /* Do the same for the backwards rules */
    size = NUMVARS *  num_bwd_rules * sizeof(int);
    abst->bwd_rule_label_sets = (int*) malloc (size);
    memcpy(abst->bwd_rule_label_sets, bwd_rule_label_sets, size);
    for (i = 0; i < num_bwd_rules; ++i) {
        for (j = 0; j < NUMVARS; ++j) {
            if (abst->project_away_var[j]) {
                n = 0;
                for (k = j + 1; k < NUMVARS; ++k)
                    if (!abst->project_away_var[k] 
                        && bwd_rule_label_sets[i*NUMVARS + k] == j)
                        found[n++] = k;
                if (n > 0) {
                    abst->bwd_rule_label_sets[i*NUMVARS + j] = found[0];
                    for (k = 0; k < n; ++k)
                        abst->bwd_rule_label_sets[i*NUMVARS + found[k]] = found[0];
                }
            }
        }
    }
#endif
}


static abstraction_t* create_identity_abstraction()
{
    int i, j;
    abstraction_t* abst = allocate_abstraction();
    if (abst == NULL)
        return NULL;

    for( i = 0; i < NUMDOMAINS; ++i )
        for( j = 0; j < domain_sizes[ i ]; ++j )
            abst->value_map[ i ][ j ] = j;
    abstraction_compute_mapped_in( abst );

    for( i = 0; i < NUMVARS; ++i )
        abst->project_away_var[ i ] = 0;

    return abst;
}


/* Reads abstraction from stream between closing curly braces.
   Assumes abstraction starts as the identity map. Only domains
   you want to change need to specified. */
static abstraction_t *read_abstraction_from_stream( FILE* stream )
{
    int i, k;
    var_t j;
    char token[1024];
    abstraction_t *abst = create_identity_abstraction();
    if (!abst)
        return NULL;

    if (!fscanf(stream, " %s", token) || token[0] != '{') {
        fprintf(stderr, "Missing opening '{'!\n");
        destroy_abstraction( abst );
        return NULL;
    }

    while (!feof(stream)) {
        if (!fscanf(stream, " %s ", token)) {
            fprintf(stderr, "Expected more input!\n");
            destroy_abstraction( abst );
            return NULL;
        }
        if (token[0] == '}')
            break;
        else if (!strcasecmp(token, "projection")) 
        {
            if (!fscanf(stream, " %s", token) || token[0] != '{') {
                fprintf(stderr, "Missing opening '{' for projection.\n");
                destroy_abstraction( abst );
                return NULL;
            }

            /* set the projection mapping */
            for( i = 0; i < NUMVARS; ++i ) {
                if(!fscanf(stream, " %s", token ) ) {
                    destroy_abstraction( abst );
                    fclose(stream);
                    return NULL;
                }
                if( token[0] == 'p' || token[0] == 'P' ) {
                    abst->project_away_var[ i ] = 1;
                } else if (token[0] == 'k' || token[0] == 'K') {
                    abst->project_away_var[ i ] = 0;
                } else {
                    fprintf(stderr, "Bad projection value: '%s'\n", token);
                    destroy_abstraction( abst );
                    return NULL;
                }
            }
            if (!fscanf(stream, " %s", token) || token[0] != '}') {
                fprintf(stderr, "Missing closing '}' after projection\n");
                destroy_abstraction( abst );
                return NULL;
            }

        } else {

            /* find domain */
            for (i = 0; i < NUMDOMAINS; ++i) {
                if (!strcasecmp(token, name_of_domain[i]))
                    break;
            }
            if (i == NUMDOMAINS) {
                fprintf(stderr, "Bad domain name! '%s'\n", token);
                destroy_abstraction( abst );
                return NULL;
            }

            if (!fscanf(stream, " %s", token) || token[0] != '{') {
                fprintf(stderr, "Missing opening '{' for domain mapping.\n");
                destroy_abstraction( abst );
                return NULL;
            }

            /* read domain mapping */
            for (j = 0; j < domain_sizes[ i ]; ++j) {
                if (!fscanf(stream, " %s", token)) {
                    fprintf(stderr, "Missing domain value!\n");
                    destroy_abstraction( abst );
                    return NULL;
                }
                for (k = 0; k < domain_sizes[i]; ++k) {
                    if (!strcasecmp(domain_to_domain_names[i][k], token))
                        break;
                }
                if (k == domain_sizes[i]) {
                    fprintf(stderr, "Bad domain value! '%s'\n", token);
                    destroy_abstraction( abst );
                    return NULL;
                }
                abst->value_map[i][j] = k;
            }

            if (!fscanf(stream, " %s", token) || token[0] != '}') {
                fprintf(stderr, "Missing closing '}' after domain mapping\n");
                destroy_abstraction( abst );
                return NULL;
            }
        }
    }

    return abst;
}


/* Reads an abstraction from a file.
   Returns the abstraction on success, or NULL on failure */
static abstraction_t *read_abstraction_from_file( const char *filename )
{
    char token[1024];
    FILE *file;
    file = fopen( filename, "r" );
    if( file == NULL )
        return NULL;

    if (!fscanf(file, "%s", token) || strcasecmp(token, "abstraction") ) {
        fprintf(stderr, "Missing opening \"abstraction\" token!\n");
        return NULL;
    }
    abstraction_t* abst = read_abstraction_from_stream( file );
    fclose( file );
    return abst;
}


static void print_abstraction( const abstraction_t* abst )
{
    int i, j;
    printf("abstraction {\n");
    for( i = 0; i < NUMDOMAINS; ++i ) {
        printf("  %s {", name_of_domain[ i ]);
        for( j = 0; j < domain_sizes[ i ]; ++j ) {
            printf(" ");
            printf("%s", domain_to_domain_names[i][ abst->value_map[i][j] ]);
        }
        printf(" }  \n");
    }
    printf("  projection {");
    for (i = 0; i < NUMVARS; ++i) {
        printf(" %c", (abst->project_away_var[i] ? 'P' : 'K'));
    }
    printf(" }\n}\n");
}


/* compute abstraction of state and store in abst_state */
static void abstract_state( const abstraction_t *abst, const state_t *state,
                            state_t* abst_state)
{
    int i;
    for( i = 0; i < NUMVARS; ++i ) {
        if( abst->project_away_var[ i ] ) {
            abst_state->vars[ i ] = 0;
        } else {
            abst_state->vars[ i ]
                = abst->value_map[ var_domains[ i ] ][ state->vars[ i ] ];
        }
    }
}
